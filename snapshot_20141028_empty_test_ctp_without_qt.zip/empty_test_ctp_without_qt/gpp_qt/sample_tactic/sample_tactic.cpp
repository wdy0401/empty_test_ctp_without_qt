#define BUILD_SAMPLE_TACTIC_DLL
#define SAMPLE_TACTIC

#include"sample_tactic.h"
#include"../wtimer/wtimer.h"
#include"../match_engine/orderlist.h"


extern wtimer tm;

extern ol;


void updateinfo(const orderlist & ol, const orderbook & ob)
{
	
}